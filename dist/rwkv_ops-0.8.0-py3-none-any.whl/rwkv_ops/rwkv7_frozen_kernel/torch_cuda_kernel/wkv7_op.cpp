#include <torch/extension.h>
#include <cuda_bf16.h>
#include <vector>

using bf = __nv_bfloat16;

/* ----------- CUDA 函数声明（来自 .cu 文件）----------- */
void cuda_frozen_forward(int B, int T, int H, 
                         bf* w, bf* q, bf* k, bf* v, bf* a, bf* b, 
                         bf* y, float* sa, float* h0);

void cuda_frozen_backward(int B, int T, int H,
                          bf* w, bf* q, bf* k, bf* v, bf* a, bf* b,
                          float* sa, bf* dy, float* h0,
                          float* dht, float* dh0,
                          bf* dw, bf* dq, bf* dk, bf* dv, bf* da, bf* db);

/* ----------- Frozen Delta Rule 前向 Wrapper ----------- */
void frozen_forward(torch::Tensor &w, torch::Tensor &q, torch::Tensor &k, 
                    torch::Tensor &v, torch::Tensor &a, torch::Tensor &b,
                    torch::Tensor &h0, torch::Tensor &y, torch::Tensor &sa) {
    // 维度提取: w, q, k, v, a, b 都是 [B, T, H, N]
    int B = w.sizes()[0];
    int T = w.sizes()[1];
    int H = w.sizes()[2];
    int N = w.sizes()[3];  // 即模板参数 C (HEAD_SIZE)
    
    // 确保 h0 是 [B, H, N, N] 的 float32
    TORCH_CHECK(h0.dtype() == torch::kFloat32, "h0 must be float32");
    TORCH_CHECK(h0.sizes()[0] == B && h0.sizes()[1] == H && 
                h0.sizes()[2] == N && h0.sizes()[3] == N, "h0 shape mismatch");
    
    // 调用 CUDA kernel
    cuda_frozen_forward(B, T, H, 
        (bf*)w.data_ptr(), (bf*)q.data_ptr(), (bf*)k.data_ptr(), 
        (bf*)v.data_ptr(), (bf*)a.data_ptr(), (bf*)b.data_ptr(),
        (bf*)y.data_ptr(), (float*)sa.data_ptr(), (float*)h0.data_ptr());
}

/* ----------- Frozen Delta Rule 反向 Wrapper ----------- */
void frozen_backward(torch::Tensor &w, torch::Tensor &q, torch::Tensor &k,
                     torch::Tensor &v, torch::Tensor &a, torch::Tensor &b,
                     torch::Tensor &sa, torch::Tensor &dy, torch::Tensor &h0,
                     torch::Tensor &dht, torch::Tensor &dh0,
                     torch::Tensor &dw, torch::Tensor &dq, torch::Tensor &dk,
                     torch::Tensor &dv, torch::Tensor &da, torch::Tensor &db) {
    int B = w.sizes()[0];
    int T = w.sizes()[1];
    int H = w.sizes()[2];
    int N = w.sizes()[3];
    
    // 检查 h0 维度
    TORCH_CHECK(h0.dtype() == torch::kFloat32, "h0 must be float32");
    
    cuda_frozen_backward(B, T, H,
        (bf*)w.data_ptr(), (bf*)q.data_ptr(), (bf*)k.data_ptr(),
        (bf*)v.data_ptr(), (bf*)a.data_ptr(), (bf*)b.data_ptr(),
        (float*)sa.data_ptr(), (bf*)dy.data_ptr(), (float*)h0.data_ptr(),
        (float*)dht.data_ptr(), (float*)dh0.data_ptr(),
        (bf*)dw.data_ptr(), (bf*)dq.data_ptr(), (bf*)dk.data_ptr(),
        (bf*)dv.data_ptr(), (bf*)da.data_ptr(), (bf*)db.data_ptr());
}

/* ----------- 算子注册 ----------- */
TORCH_LIBRARY(frozen_wind_backstepping, m) {
    m.def("forward(Tensor w, Tensor q, Tensor k, Tensor v, Tensor a, Tensor b, Tensor h0, Tensor(a!) y, Tensor(b!) sa) -> ()");
    m.def("backward(Tensor w, Tensor q, Tensor k, Tensor v, Tensor a, Tensor b, Tensor sa, Tensor dy, Tensor h0, Tensor dht, Tensor(a!) dh0, Tensor(b!) dw, Tensor(c!) dq, Tensor(d!) dk, Tensor(e!) dv, Tensor(f!) da, Tensor(g!) db) -> ()");
}

TORCH_LIBRARY_IMPL(frozen_wind_backstepping, CUDA, m) {
    m.impl("forward", &frozen_forward);
    m.impl("backward", &frozen_backward);
}