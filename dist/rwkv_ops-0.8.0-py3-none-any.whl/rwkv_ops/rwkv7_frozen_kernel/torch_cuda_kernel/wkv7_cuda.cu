#include <cuda_bf16.h>
#include <assert.h>
#include <cstdint>

using bf = __nv_bfloat16;

__device__ inline float to_float(const bf & u) {
    return __bfloat162float(u);
}

__device__ inline bf to_bf(const float & u) {
    return __float2bfloat16_rn(u);
}
typedef bf * __restrict__ F_;

// -------------------- Frozen Delta Rule Kernels -------------------- 

template<int C> __launch_bounds__(C, 2)
__global__ void frozen_forward_kernel(int T, int H,
     F_ w_, F_ q_, F_ k_, F_ v_, F_ a_, F_ b_,
     bf* y_, float* sa_, const float* __restrict__ h0_) {  // 【修改】改为 bf16 指针
    int bb = blockIdx.y, hh = blockIdx.x, i = threadIdx.x;
    float state[C] = {0};
    __shared__ float q[C], k[C], w[C], a[C], b[C];

    int64_t h0_base = ((int64_t)bb*H + hh)*C*C + i*C; 
    #pragma unroll
    for (int j = 0; j < C; j++) state[j] = h0_[h0_base + j];
    
    for (int t = 0; t < T; t++) {
        int64_t ind = (int64_t)bb*T*H*C + (int64_t)t*H*C + hh * C + i;

        __syncthreads();
        q[i] = to_float(q_[ind]);
        w[i] = __expf(-__expf(to_float(w_[ind])));
        k[i] = to_float(k_[ind]);
        a[i] = to_float(a_[ind]);
        b[i] = to_float(b_[ind]);
        __syncthreads();
        
        float sa_val = 0;
        #pragma unroll
        for (int j = 0; j < C; j++) sa_val += a[j] * state[j];
        sa_[ind] = sa_val;
        
        float v_val = to_float(v_[ind]);
        float y = 0;
        #pragma unroll
        for (int j = 0; j < C; j++) {
            float s_prev = state[j];
            float s_cand = s_prev * w[j] + sa_val * b[j] + k[j] * v_val;
            y += s_cand * q[j];
        }
        y_[ind] = to_bf(y);
    }
}

template<int C> __launch_bounds__(C, 2)
__global__ void frozen_backward_kernel(int T, int H, 
    F_ w_, F_ q_, F_ k_, F_ v_, F_ a_, F_ b_, 
    const float* __restrict__ sa_,
    F_ dy_,
    const float* __restrict__ h0,
    float * __restrict__ dht,
    float * __restrict__ dh0,
    bf* dw_, bf* dq_, bf* dk_, bf* dv_, bf* da_, bf* db_) {
    
    int bb = blockIdx.y, hh = blockIdx.x, i = threadIdx.x;
    
    // mask=0 特化：m=0, one_minus_m=1
    const float m = 0.0f;
    const float one_minus_m = 1.0f;
    
    // 从 h0 加载 stateT（恒定，不逆推）
    float stateT[C];
    int64_t h0_base = ((int64_t)bb * H + hh) * C * C;
    #pragma unroll
    for (int j = 0; j < C; j++) {
        stateT[j] = h0[h0_base + j * C + i];
    }
    
    // 初始化梯度（从 dht 加载）
    float dstate[C] = {0}, dstateT[C] = {0};
    int64_t dht_base = ((int64_t)bb * H + hh) * C * C + i * C;
    #pragma unroll
    for (int j = 0; j < C; j++) {
        dstate[j] = dht[dht_base + j];
        dstateT[j] = dht[dht_base + j];
    }
    
    __shared__ float w[C], q[C], k[C], v[C], a[C], b[C], dy[C], sa[C], dSb_shared[C];
    float qi, wi, ki, ai, bi, dyi;

    for (int t = T - 1; t >= 0; t--) {
        int64_t ind = (int64_t)bb * T * H * C + (int64_t)t * H * C + hh * C + i;
        
        __syncthreads();
        q[i] = qi = to_float(q_[ind]);
        float wi_fac = -__expf(to_float(w_[ind]));
        w[i] = wi = __expf(wi_fac);
        k[i] = ki = to_float(k_[ind]);
        v[i] = to_float(v_[ind]);
        a[i] = ai = to_float(a_[ind]);
        b[i] = bi = to_float(b_[ind]);
        dy[i] = dyi = to_float(dy_[ind]);
        sa[i] = sa_[ind];
        __syncthreads();

        // dq计算：m=0时使用候选状态 s_cand
        float dq_val = 0;
        #pragma unroll
        for (int j = 0; j < C; j++) {
            float s_cand = stateT[j] * wi + sa[j] * bi + v[j] * ki;
            float s_for_dq = one_minus_m * s_cand;  // m=0 时等于 s_cand
            dq_val += s_for_dq * dy[j];
        }
        dq_[ind] = to_bf(dq_val);
        
        // 累加当前输出梯度
        #pragma unroll
        for (int j = 0; j < C; j++) {
            dstate[j] += dyi * q[j];
            dstateT[j] += qi * dy[j];
        }
        
        // 保存完整梯度
        float dstate_old[C], dstateT_old[C];
        #pragma unroll
        for (int j = 0; j < C; j++) {
            dstate_old[j] = dstate[j];
            dstateT_old[j] = dstateT[j];
        }
        
        // m=0时：stateT 保持为 h0（不逆推）
        // stateT[j] = m * s_prev + one_minus_m * stateT[j] = stateT[j]
        
        // m=0时：dstate_param = dstate_curr（仅用当前步梯度）
        float dstate_param[C], dstateT_param[C];
        #pragma unroll
        for (int j = 0; j < C; j++) {
            float dstate_curr = dyi * q[j];
            float dstateT_curr = qi * dy[j];
            dstate_param[j] = one_minus_m * dstate_curr;  // = dstate_curr
            dstateT_param[j] = one_minus_m * dstateT_curr; // = dstateT_curr
        }
        
        // 参数梯度计算（使用dstate_param和恒定的stateT）
        float dw = 0, dk = 0, dv = 0, db = 0, dSb = 0;
        #pragma unroll
        for (int j = 0; j < C; j++) {
            dw += dstateT_param[j] * stateT[j];
            dk += dstateT_param[j] * v[j];
            dv += dstate_param[j] * k[j];
            dSb += dstate_param[j] * b[j];
            db += dstateT_param[j] * sa[j];
        }
        
        dw_[ind] = to_bf(dw * wi * wi_fac);
        dk_[ind] = to_bf(dk);
        dv_[ind] = to_bf(dv);
        db_[ind] = to_bf(db);
        
        __syncthreads();
        dSb_shared[i] = dSb;
        __syncthreads();
        
        float da = 0;
        #pragma unroll
        for (int j = 0; j < C; j++) {
            da += stateT[j] * dSb_shared[j];
        }
        da_[ind] = to_bf(da);
        
        // m=0时的梯度回传：trans + penetration
        // penetration = dstate_old - dstate_param
        #pragma unroll
        for (int j = 0; j < C; j++) {
            float trans_row = dstate_param[j] * w[j] + dSb * a[j];
            float trans_col = dstateT_param[j] * wi + ai * dSb_shared[j];
            
            float penetration_row = dstate_old[j] - dstate_param[j];
            float penetration_col = dstateT_old[j] - dstateT_param[j];
            
            // dstate = trans + penetration（因为 one_minus_m=1）
            dstate[j] = trans_row + penetration_row;
            dstateT[j] = trans_col + penetration_col;
        }
    }
    
    // 写入 dh0（所有时间步的穿透累加结果）
    #pragma unroll
    for (int j = 0; j < C; j++) {
        dh0[dht_base + j] = dstate[j];
    }
}

/* -------------------- C 接口函数 -------------------- */

// 注意：使用 _C_ 宏作为编译时确定的 HEAD_SIZE
void cuda_frozen_forward(int B, int T, int H, 
                         bf* w, bf* q, bf* k, bf* v, bf* a, bf* b, 
                         bf* y, float* sa, float* h0) {
    frozen_forward_kernel<_C_><<<dim3(H, B), dim3(_C_)>>>(T, H, w, q, k, v, a, b, y, sa, h0);
}

void cuda_frozen_backward(int B, int T, int H,
                          bf* w, bf* q, bf* k, bf* v, bf* a, bf* b,
                          float* sa, bf* dy, float* h0,
                          float* dht, float* dh0,
                          bf* dw, bf* dq, bf* dk, bf* dv, bf* da, bf* db) {
    // frozen 版本不需要 T 被 CHUNK_LEN 整除（因为没有分块保存）
    frozen_backward_kernel<_C_><<<dim3(H, B), dim3(_C_)>>>(
        T, H, w, q, k, v, a, b, sa, dy, h0, dht, dh0, dw, dq, dk, dv, da, db);
}