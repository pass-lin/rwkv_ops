import os
import torch
from torch.utils.cpp_extension import load
from keras.src.backend.torch.core import cast
from keras.src.backend.torch.numpy import transpose


def transpose_head(x, head_first):
    """转置 head 维度，适配 CUDA kernel 的内存布局"""
    if head_first:
        return transpose(x, (0, 2, 1, 3))
    else:
        return x


def get_torch_frozen_delta_rule(HEAD_SIZE=64):
    """
    加载并返回 Frozen Delta Rule (mask=0 特化) 的 CUDA 算子。

    特性：
    - 状态恒定为 initial_state，不随时间更新
    - 不保存中间状态矩阵（节省显存）
    - 梯度穿透累加到初始状态

    Args:
        HEAD_SIZE: 头维度大小（默认64），编译时确定以优化性能
    """
    CHUNK_LEN = 16  # 保持与原版一致，虽然 frozen 版本不需要分块保存状态
    flags = [
        "-res-usage",
        f"-D_C_={HEAD_SIZE}",
        f"-D_CHUNK_LEN_={CHUNK_LEN}",
        "--use_fast_math",
        "-O3",
        "-Xptxas -O3",
        "--extra-device-vectorization",
    ]

    current_file_path = os.path.abspath(__file__)
    current_dir_path = os.path.dirname(current_file_path)

    # 加载 frozen 专用算子库（独立的 so 文件）
    load(
        name="frozen_wind_backstepping",
        sources=[
            os.path.join(current_dir_path, "wkv7_cuda.cu"),
            os.path.join(current_dir_path, "wkv7_op.cpp"),
        ],
        is_python_module=False,
        verbose=True,
        extra_cuda_cflags=flags,
    )

    # ============================================================
    # Frozen Delta Rule Autograd Function（核心实现）
    # ============================================================
    class FrozenDeltaRule(torch.autograd.Function):
        @staticmethod
        def forward(ctx, w, q, k, v, a, b, h0):
            """
            前向传播：状态恒定，仅基于初始状态 h0 计算输出

            Args:
                w, q, k, v, a, b: [B, T, H, N], bfloat16
                h0: [B, H, N, N], float32（强制要求，不可为None）

            Returns:
                y: [B, T, H, N], 与输入相同 dtype
                # 注意：不返回最终状态，因为 state 始终等于 h0
            """
            B, T, H, N = w.shape
            DTYPE = q.dtype

            # 类型转换与连续性保证
            q, k, v, a, b, w = [
                cast(x, "bfloat16").contiguous() for x in [q, k, v, a, b, w]
            ]
            # h0 必须是 float32，且必须在 CUDA 上
            h0 = cast(h0, "float32").contiguous()

            # 分配输出缓冲区
            y = torch.empty_like(v)
            # sa: [B, T, H, N]，保存 state @ a 供反向使用（避免重复计算）
            sa = torch.empty(B, T, H, N, dtype=torch.float32, device=w.device)

            # 调用 CUDA 前向算子
            # 注意：frozen 版本不需要 CHUNK_LEN 整除检查（无分块保存）
            torch.ops.frozen_wind_backstepping.forward(w, q, k, v, a, b, h0, y, sa)

            # 保存反向所需张量（注意：不需要保存 s，因为状态恒定）
            ctx.save_for_backward(w, q, k, v, a, b, h0, sa)
            ctx.HEAD_SIZE = N  # 保存维度信息供反向使用

            return cast(y, DTYPE)

        @staticmethod
        def backward(ctx, dy):
            """
            反向传播：梯度穿透累加到 dh0

            Args:
                dy: [B, T, H, N], 输出梯度

            Returns:
                dw, dq, dk, dv, da, db: 与输入同 shape 的梯度
                dh0: [B, H, N, N]，初始状态梯度（穿透累加结果）
            """
            DTYPE = ctx.saved_tensors[0].dtype
            w, q, k, v, a, b, h0, sa = ctx.saved_tensors
            N = ctx.HEAD_SIZE

            # 类型转换
            dy = cast(dy, "bfloat16").contiguous()

            # 分配梯度缓冲区
            # dht: 最终时刻状态梯度，对于 frozen 版本通常为 0（因为不输出状态）
            # 但为了接口统一，我们分配并初始化为 0
            dht = torch.zeros(
                w.shape[0],
                w.shape[2],
                N,
                N,  # [B, H, N, N]
                dtype=torch.float32,
                device=w.device,
            )
            dh0 = torch.empty_like(dht)  # 输出：初始状态梯度

            dw, dq, dk, dv, da, db = [torch.empty_like(x) for x in [w, q, k, v, a, b]]

            # 调用 CUDA 反向算子
            torch.ops.frozen_wind_backstepping.backward(
                w, q, k, v, a, b, sa, dy, h0, dht, dh0, dw, dq, dk, dv, da, db
            )

            # 返回 7 个梯度（对应 7 个输入参数）
            return (
                cast(dw, DTYPE),
                cast(dq, DTYPE),
                cast(dk, DTYPE),
                cast(dv, DTYPE),
                cast(da, DTYPE),
                cast(db, DTYPE),
                dh0,  # h0 的梯度（float32）
            )

    # ============================================================
    # 对外接口函数
    # ============================================================
    def frozen_delta_rule(
        r,
        w,
        k,
        v,
        a,
        b,
        initial_state,
        head_first: bool = False,
    ):
        """
        Frozen Delta Rule 统一接口。

        与 generalized_delta_rule 的关键区别：
        1. initial_state 必须提供（不可为None），且状态始终保持不变
        2. 不输出最终状态（因为始终等于 initial_state）
        3. 无 mask 参数（行为固定为 mask=0）

        Args:
            r: receptance/query，[B, T, H, N] 或 [B, H, T, N]（若 head_first=True）
            w: decay weight，同上
            k, v, a, b: 输入张量，同上
            initial_state: [B, H, N, N]，float32，**必须提供**，状态冻结为此值
            head_first: 若为 True，输入输出维度为 [B, H, T, N]，否则 [B, T, H, N]

        Returns:
            out: [B, T, H, N]（若 head_first 则为 [B, H, T, N]），与 r 同 dtype
            # 注意：不返回状态（与 generalized_delta_rule 不同）
        """
        # 强制要求 initial_state
        if initial_state is None:
            raise ValueError(
                "frozen_delta_rule requires explicit initial_state (cannot be None). "
                "The state is frozen to this initial value throughout the sequence."
            )

        # CPU 回退（可选：若需要纯 PyTorch 实现）
        if w.device.type != "cuda":
            raise NotImplementedError(
                "frozen_delta_rule currently only supports CUDA. "
                "Please use CUDA tensors or implement CPU fallback."
            )

        # 维度转置：统一到 [B, T, H, N]（head_last）供 CUDA kernel 处理
        r = transpose_head(r, head_first)
        k = transpose_head(k, head_first)
        v = transpose_head(v, head_first)
        a = transpose_head(a, head_first)
        b = transpose_head(b, head_first)
        w = transpose_head(w, head_first)

        # 确保 initial_state 是 float32 且在正确设备上
        if initial_state.dtype != torch.float32:
            initial_state = initial_state.to(torch.float32)
        if initial_state.device != w.device:
            initial_state = initial_state.to(w.device)

        # 调用 Autograd Function
        out = FrozenDeltaRule.apply(w, r, k, v, a, b, initial_state)

        # 如果输入是 head_first，输出转回 [B, H, T, N]
        if head_first:
            out = transpose(out, (0, 2, 1, 3))

        return out

    return frozen_delta_rule
