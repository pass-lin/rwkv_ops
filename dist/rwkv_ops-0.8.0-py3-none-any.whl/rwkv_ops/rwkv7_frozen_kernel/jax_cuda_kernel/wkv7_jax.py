"""
JAX 版 Frozen Delta Rule (mask=0 特化)
状态恒定为 initial_state，不随时间更新
"""

from __future__ import annotations
import pathlib
import subprocess
import ctypes
import jax
import jax.numpy as jnp
from typing import Optional, Tuple, Union

CHUNK_LEN = 16  # 保持与 CMake 一致，虽然 frozen 版本不需要分块

# ---------- 延迟编译 ----------
_CURRENT_DIR = pathlib.Path(__file__).parent.absolute()


def get_jax_frozen_delta_rule(HEAD_SIZE=64):
    _BUILD_DIR = _CURRENT_DIR / f"build_{HEAD_SIZE}"
    _SO_PATH = _CURRENT_DIR / f"build_{HEAD_SIZE}/wkv7.so"  # CMake 产出名为 wkv7.so

    def _ensure_compiled() -> pathlib.Path:
        """首次调用时编译 CUDA 扩展"""
        if _SO_PATH.exists():
            return _SO_PATH

        print("[frozen_wkv7_jax] First use – compiling CUDA kernel…")
        src_dir = _CURRENT_DIR
        build_dir = _BUILD_DIR
        build_dir.mkdir(exist_ok=True)

        xla_include_dir = jax.ffi.include_dir()
        if not xla_include_dir:
            raise RuntimeError("jax.ffi.include_dir() 返回空，请检查 JAX >= 0.4.31")

        cuda_flags = [
            "-ftz=true",
            "-prec-div=false",
            "-prec-sqrt=false",
            "--use_fast_math",
            "-O3",
            "-Xptxas=-O3",
            "-res-usage",
            "--extra-device-vectorization",
            f"-D_C_={HEAD_SIZE}",
            f"-D_CHUNK_LEN_={CHUNK_LEN}",
        ]

        cmake_args = [
            "cmake",
            "-S",
            str(src_dir),
            "-B",
            str(build_dir),
            "-DCMAKE_BUILD_TYPE=Release",
            f"-DCMAKE_INSTALL_PREFIX={_CURRENT_DIR}",
            f"-DXLA_INCLUDE_DIR={xla_include_dir}",
            f"-DCMAKE_CUDA_FLAGS={' '.join(cuda_flags)}",
        ]
        subprocess.check_call(cmake_args)
        subprocess.check_call(["cmake", "--build", str(build_dir), "-j"])
        subprocess.check_call(["cmake", "--install", str(build_dir)])

        if not _SO_PATH.exists():
            raise RuntimeError("Compilation failed – wkv7.so not found.")
        print("[frozen_wkv7_jax] Compilation finished – output at", _SO_PATH)
        return _SO_PATH

    # 注册 FFI 符号
    _lib = ctypes.CDLL(_ensure_compiled())
    jax.ffi.register_ffi_target(
        "frozen_fwd", jax.ffi.pycapsule(_lib.FrozenFwd), platform="CUDA"
    )
    jax.ffi.register_ffi_target(
        "frozen_bwd", jax.ffi.pycapsule(_lib.FrozenBwd), platform="CUDA"
    )

    def _transpose_head(x: jnp.ndarray, head_first: bool) -> jnp.ndarray:
        """(B, T, H, K) <-> (B, H, T, K)"""
        x = jnp.asarray(x, dtype=jnp.bfloat16)
        if head_first:
            return jnp.transpose(x, (0, 2, 1, 3))
        return x

    # ---------- 前向 Kernel ----------
    def _frozen_fwd_kernel(
        w: jnp.ndarray,
        q: jnp.ndarray,
        k: jnp.ndarray,
        v: jnp.ndarray,
        a: jnp.ndarray,
        b: jnp.ndarray,
        h0: jnp.ndarray,
    ):
        B, T, H, K = q.shape
        dtype = q.dtype

        out_type = jax.ShapeDtypeStruct((B, T, H, K), dtype)
        sa_type = jax.ShapeDtypeStruct((B, T, H, K), jnp.float32)

        y, sa = jax.ffi.ffi_call(
            "frozen_fwd", (out_type, sa_type), vmap_method="broadcast_all"
        )(w, q, k, v, a, b, h0)

        return y, sa

    @jax.custom_vjp
    def frozen_kernel(w, q, k, v, a, b, h0):
        y, sa = _frozen_fwd_kernel(w, q, k, v, a, b, h0)
        return y  # frozen 版本不返回最终状态（因为等于 h0）

    def _frozen_fwd(w, q, k, v, a, b, h0):
        y, sa = _frozen_fwd_kernel(w, q, k, v, a, b, h0)
        # 保存反向所需：所有输入 + sa + h0
        return y, (w, q, k, v, a, b, h0, sa)

    def _frozen_bwd(res, grads):
        w, q, k, v, a, b, h0, sa = res
        dy = jnp.asarray(grads, jnp.bfloat16)

        B, T, H, K = q.shape
        # dht: 最终状态梯度，对于 frozen 通常为 0（因为不输出状态）
        dht = jnp.zeros((B, H, K, K), jnp.float32)

        dh0_type = jax.ShapeDtypeStruct(h0.shape, h0.dtype)
        dw_type = jax.ShapeDtypeStruct(w.shape, w.dtype)
        dq_type = jax.ShapeDtypeStruct(q.shape, q.dtype)
        dk_type = jax.ShapeDtypeStruct(k.shape, k.dtype)
        dv_type = jax.ShapeDtypeStruct(v.shape, v.dtype)
        da_type = jax.ShapeDtypeStruct(a.shape, a.dtype)
        db_type = jax.ShapeDtypeStruct(b.shape, b.dtype)

        dh0, dw, dq, dk, dv, da, db = jax.ffi.ffi_call(
            "frozen_bwd",
            (dh0_type, dw_type, dq_type, dk_type, dv_type, da_type, db_type),
            vmap_method="broadcast_all",
        )(w, q, k, v, a, b, sa, dy, h0, dht)

        return dw, dq, dk, dv, da, db, dh0

    frozen_kernel.defvjp(_frozen_fwd, _frozen_bwd)

    # ---------- 公共 API ----------
    def frozen_delta_rule(
        r: jnp.ndarray,
        w: jnp.ndarray,
        k: jnp.ndarray,
        v: jnp.ndarray,
        a: jnp.ndarray,
        b: jnp.ndarray,
        initial_state: jnp.ndarray,
        head_first: bool = False,
    ) -> jnp.ndarray:
        """
        Frozen Delta Rule - 状态恒定为 initial_state，不随时间更新

        与 generalized_delta_rule 的关键区别：
        1. initial_state 必须提供（不可为None）
        2. 不输出最终状态（因为始终等于 initial_state）
        3. 无 mask 参数（行为固定为 mask=0）

        Args:
            r,w,k,v,a,b: [B, T, H, K] 或 [B, H, T, K]（若 head_first=True）
            initial_state: [B, H, K, K]，float32，**必须提供**
            head_first: 是否将 head 维提前

        Returns:
            out: [B, T, H, K]，与输入 dtype 一致
        """
        if initial_state is None:
            raise ValueError(
                "frozen_delta_rule requires explicit initial_state (cannot be None). "
                "The state is frozen to this initial value throughout the sequence."
            )

        # 统一转置到 [B, T, H, K]
        dtype = r.dtype
        r = _transpose_head(r, head_first)
        w = _transpose_head(w, head_first)
        k = _transpose_head(k, head_first)
        v = _transpose_head(v, head_first)
        a = _transpose_head(a, head_first)
        b = _transpose_head(b, head_first)

        # 确保 initial_state 是 float32
        h0 = jnp.asarray(initial_state, jnp.float32)

        out = frozen_kernel(w, r, k, v, a, b, h0)

        if head_first:
            out = jnp.transpose(out, (0, 2, 1, 3))

        return jnp.asarray(out, dtype)

    return frozen_delta_rule
