#include <cuda_bf16.h>
#include <cuda_runtime.h>
#include <xla/ffi/api/ffi.h>
#include <vector>
#include <cstdint>

namespace ffi = xla::ffi;

/* -------------------- 类型别名 -------------------- */
using bf = __nv_bfloat16;

__device__ inline float to_float(const bf &u) {
    return __bfloat162float(u);
}
__device__ inline bf to_bf(const float &u) {
    return __float2bfloat16_rn(u);
}
typedef bf *__restrict__ F_;

/* -------------------- Frozen Forward Kernel -------------------- 
 * 特性：状态恒定为 h0，不随时间更新（mask=0 特化）
 */
template<int C> __launch_bounds__(C, 2)
__global__ void frozen_forward_kernel(int T, int H,
     F_ w_, F_ q_, F_ k_, F_ v_, F_ a_, F_ b_,
     bf* y_, float* sa_, const float* __restrict__ h0_) {  // 【修改】改为 bf16 指针
    int bb = blockIdx.y, hh = blockIdx.x, i = threadIdx.x;
    float state[C] = {0};
    __shared__ float q[C], k[C], w[C], a[C], b[C];

    int64_t h0_base = ((int64_t)bb*H + hh)*C*C + i*C; 
    #pragma unroll
    for (int j = 0; j < C; j++) state[j] = h0_[h0_base + j];
    
    for (int t = 0; t < T; t++) {
        int64_t ind = (int64_t)bb*T*H*C + (int64_t)t*H*C + hh * C + i;

        __syncthreads();
        q[i] = to_float(q_[ind]);
        w[i] = __expf(-__expf(to_float(w_[ind])));
        k[i] = to_float(k_[ind]);
        a[i] = to_float(a_[ind]);
        b[i] = to_float(b_[ind]);
        __syncthreads();
        
        float sa_val = 0;
        #pragma unroll
        for (int j = 0; j < C; j++) sa_val += a[j] * state[j];
        sa_[ind] = sa_val;
        
        float v_val = to_float(v_[ind]);
        float y = 0;
        #pragma unroll
        for (int j = 0; j < C; j++) {
            float s_prev = state[j];
            float s_cand = s_prev * w[j] + sa_val * b[j] + k[j] * v_val;
            y += s_cand * q[j];
        }
        y_[ind] = to_bf(y);
    }
}

template<int C> __launch_bounds__(C, 2)
__global__ void frozen_backward_kernel(int T, int H, 
    F_ w_, F_ q_, F_ k_, F_ v_, F_ a_, F_ b_, 
    const float* __restrict__ sa_,
    F_ dy_,
    const float* __restrict__ h0,
    float * __restrict__ dht,
    float * __restrict__ dh0,
    bf* dw_, bf* dq_, bf* dk_, bf* dv_, bf* da_, bf* db_) {
    
    int bb = blockIdx.y, hh = blockIdx.x, i = threadIdx.x;
    
    // mask=0 特化：m=0, one_minus_m=1
    const float m = 0.0f;
    const float one_minus_m = 1.0f;
    
    // 从 h0 加载 stateT（恒定，不逆推）
    float stateT[C];
    int64_t h0_base = ((int64_t)bb * H + hh) * C * C;
    #pragma unroll
    for (int j = 0; j < C; j++) {
        stateT[j] = h0[h0_base + j * C + i];
    }
    
    // 初始化梯度（从 dht 加载）
    float dstate[C] = {0}, dstateT[C] = {0};
    int64_t dht_base = ((int64_t)bb * H + hh) * C * C + i * C;
    #pragma unroll
    for (int j = 0; j < C; j++) {
        dstate[j] = dht[dht_base + j];
        dstateT[j] = dht[dht_base + j];
    }
    
    __shared__ float w[C], q[C], k[C], v[C], a[C], b[C], dy[C], sa[C], dSb_shared[C];
    float qi, wi, ki, ai, bi, dyi;

    for (int t = T - 1; t >= 0; t--) {
        int64_t ind = (int64_t)bb * T * H * C + (int64_t)t * H * C + hh * C + i;
        
        __syncthreads();
        q[i] = qi = to_float(q_[ind]);
        float wi_fac = -__expf(to_float(w_[ind]));
        w[i] = wi = __expf(wi_fac);
        k[i] = ki = to_float(k_[ind]);
        v[i] = to_float(v_[ind]);
        a[i] = ai = to_float(a_[ind]);
        b[i] = bi = to_float(b_[ind]);
        dy[i] = dyi = to_float(dy_[ind]);
        sa[i] = sa_[ind];
        __syncthreads();

        // dq计算：m=0时使用候选状态 s_cand
        float dq_val = 0;
        #pragma unroll
        for (int j = 0; j < C; j++) {
            float s_cand = stateT[j] * wi + sa[j] * bi + v[j] * ki;
            float s_for_dq = one_minus_m * s_cand;  // m=0 时等于 s_cand
            dq_val += s_for_dq * dy[j];
        }
        dq_[ind] = to_bf(dq_val);
        
        // 累加当前输出梯度
        #pragma unroll
        for (int j = 0; j < C; j++) {
            dstate[j] += dyi * q[j];
            dstateT[j] += qi * dy[j];
        }
        
        // 保存完整梯度
        float dstate_old[C], dstateT_old[C];
        #pragma unroll
        for (int j = 0; j < C; j++) {
            dstate_old[j] = dstate[j];
            dstateT_old[j] = dstateT[j];
        }
        
        // m=0时：stateT 保持为 h0（不逆推）
        // stateT[j] = m * s_prev + one_minus_m * stateT[j] = stateT[j]
        
        // m=0时：dstate_param = dstate_curr（仅用当前步梯度）
        float dstate_param[C], dstateT_param[C];
        #pragma unroll
        for (int j = 0; j < C; j++) {
            float dstate_curr = dyi * q[j];
            float dstateT_curr = qi * dy[j];
            dstate_param[j] = one_minus_m * dstate_curr;  // = dstate_curr
            dstateT_param[j] = one_minus_m * dstateT_curr; // = dstateT_curr
        }
        
        // 参数梯度计算（使用dstate_param和恒定的stateT）
        float dw = 0, dk = 0, dv = 0, db = 0, dSb = 0;
        #pragma unroll
        for (int j = 0; j < C; j++) {
            dw += dstateT_param[j] * stateT[j];
            dk += dstateT_param[j] * v[j];
            dv += dstate_param[j] * k[j];
            dSb += dstate_param[j] * b[j];
            db += dstateT_param[j] * sa[j];
        }
        
        dw_[ind] = to_bf(dw * wi * wi_fac);
        dk_[ind] = to_bf(dk);
        dv_[ind] = to_bf(dv);
        db_[ind] = to_bf(db);
        
        __syncthreads();
        dSb_shared[i] = dSb;
        __syncthreads();
        
        float da = 0;
        #pragma unroll
        for (int j = 0; j < C; j++) {
            da += stateT[j] * dSb_shared[j];
        }
        da_[ind] = to_bf(da);
        
        // m=0时的梯度回传：trans + penetration
        // penetration = dstate_old - dstate_param
        #pragma unroll
        for (int j = 0; j < C; j++) {
            float trans_row = dstate_param[j] * w[j] + dSb * a[j];
            float trans_col = dstateT_param[j] * wi + ai * dSb_shared[j];
            
            float penetration_row = dstate_old[j] - dstate_param[j];
            float penetration_col = dstateT_old[j] - dstateT_param[j];
            
            // dstate = trans + penetration（因为 one_minus_m=1）
            dstate[j] = trans_row + penetration_row;
            dstateT[j] = trans_col + penetration_col;
        }
    }
    
    // 写入 dh0（所有时间步的穿透累加结果）
    #pragma unroll
    for (int j = 0; j < C; j++) {
        dh0[dht_base + j] = dstate[j];
    }
}
/* -------------------- Host 函数 -------------------- */
static ffi::Error FrozenForwardHost(
    cudaStream_t stream,
    ffi::Buffer<ffi::BF16> w,
    ffi::Buffer<ffi::BF16> q,
    ffi::Buffer<ffi::BF16> k,
    ffi::Buffer<ffi::BF16> v,
    ffi::Buffer<ffi::BF16> a,
    ffi::Buffer<ffi::BF16> b,
    ffi::Buffer<ffi::F32>  h0,
    ffi::ResultBuffer<ffi::BF16> y,
    ffi::ResultBuffer<ffi::F32>  sa)
{
    auto dims = w.dimensions();
    int B = dims[0], T = dims[1], H = dims[2];
    constexpr int C = _C_;
    dim3 block(C);
    dim3 grid(H, B);

    frozen_forward_kernel<_C_><<<grid, block, 0, stream>>>(
        T, H,
        reinterpret_cast<bf *>(w.typed_data()),
        reinterpret_cast<bf *>(q.typed_data()),
        reinterpret_cast<bf *>(k.typed_data()),
        reinterpret_cast<bf *>(v.typed_data()),
        reinterpret_cast<bf *>(a.typed_data()),
        reinterpret_cast<bf *>(b.typed_data()),
        reinterpret_cast<bf *>(y->typed_data()),
        sa->typed_data(),
        h0.typed_data());

    cudaError_t err = cudaGetLastError();
    if (err != cudaSuccess)
        return ffi::Error::Internal(
            std::string("CUDA frozen_forward_kernel error: ") + cudaGetErrorString(err));
    return ffi::Error::Success();
}

static ffi::Error FrozenBackwardHost(
    cudaStream_t stream,
    ffi::Buffer<ffi::BF16> w,
    ffi::Buffer<ffi::BF16> q,
    ffi::Buffer<ffi::BF16> k,
    ffi::Buffer<ffi::BF16> v,
    ffi::Buffer<ffi::BF16> a,
    ffi::Buffer<ffi::BF16> b,
    ffi::Buffer<ffi::F32>  sa,
    ffi::Buffer<ffi::BF16> dy,
    ffi::Buffer<ffi::F32>  h0,
    ffi::Buffer<ffi::F32>  dht,
    ffi::ResultBuffer<ffi::F32> dh0,
    ffi::ResultBuffer<ffi::BF16> dw,
    ffi::ResultBuffer<ffi::BF16> dq,
    ffi::ResultBuffer<ffi::BF16> dk,
    ffi::ResultBuffer<ffi::BF16> dv,
    ffi::ResultBuffer<ffi::BF16> da,
    ffi::ResultBuffer<ffi::BF16> db)
{
    auto dims = w.dimensions();
    int B = dims[0], T = dims[1], H = dims[2];
    constexpr int C = _C_;
    dim3 block(C);
    dim3 grid(H, B);

    frozen_backward_kernel<_C_><<<grid, block, 0, stream>>>(
        T, H,
        reinterpret_cast<bf *>(w.typed_data()),
        reinterpret_cast<bf *>(q.typed_data()),
        reinterpret_cast<bf *>(k.typed_data()),
        reinterpret_cast<bf *>(v.typed_data()),
        reinterpret_cast<bf *>(a.typed_data()),
        reinterpret_cast<bf *>(b.typed_data()),
        sa.typed_data(),
        reinterpret_cast<bf *>(dy.typed_data()),
        h0.typed_data(),
        dht.typed_data(),
        dh0->typed_data(),
        reinterpret_cast<bf *>(dw->typed_data()),
        reinterpret_cast<bf *>(dq->typed_data()),
        reinterpret_cast<bf *>(dk->typed_data()),
        reinterpret_cast<bf *>(dv->typed_data()),
        reinterpret_cast<bf *>(da->typed_data()),
        reinterpret_cast<bf *>(db->typed_data()));

    cudaError_t err = cudaGetLastError();
    if (err != cudaSuccess)
        return ffi::Error::Internal(
            std::string("CUDA frozen_backward_kernel error: ") + cudaGetErrorString(err));
    return ffi::Error::Success();
}

/* -------------------- FFI 注册 -------------------- */
XLA_FFI_DEFINE_HANDLER_SYMBOL(
    FrozenFwd, FrozenForwardHost,
    ffi::Ffi::Bind()
        .Ctx<ffi::PlatformStream<cudaStream_t>>()
        .Arg<ffi::Buffer<ffi::BF16>>()   // w
        .Arg<ffi::Buffer<ffi::BF16>>()   // q
        .Arg<ffi::Buffer<ffi::BF16>>()   // k
        .Arg<ffi::Buffer<ffi::BF16>>()   // v
        .Arg<ffi::Buffer<ffi::BF16>>()   // a
        .Arg<ffi::Buffer<ffi::BF16>>()   // b
        .Arg<ffi::Buffer<ffi::F32>>()    // h0 (initial state)
        .Ret<ffi::Buffer<ffi::BF16>>()   // y
        .Ret<ffi::Buffer<ffi::F32>>()    // sa (saved for backward)
, {ffi::Traits::kCmdBufferCompatible});

XLA_FFI_DEFINE_HANDLER_SYMBOL(
    FrozenBwd, FrozenBackwardHost,
    ffi::Ffi::Bind()
        .Ctx<ffi::PlatformStream<cudaStream_t>>()
        .Arg<ffi::Buffer<ffi::BF16>>()   // w
        .Arg<ffi::Buffer<ffi::BF16>>()   // q
        .Arg<ffi::Buffer<ffi::BF16>>()   // k
        .Arg<ffi::Buffer<ffi::BF16>>()   // v
        .Arg<ffi::Buffer<ffi::BF16>>()   // a
        .Arg<ffi::Buffer<ffi::BF16>>()   // b
        .Arg<ffi::Buffer<ffi::F32>>()    // sa (from forward)
        .Arg<ffi::Buffer<ffi::BF16>>()   // dy
        .Arg<ffi::Buffer<ffi::F32>>()    // h0 (original initial state)
        .Arg<ffi::Buffer<ffi::F32>>()    // dht (usually zero)
        .Ret<ffi::Buffer<ffi::F32>>()    // dh0 (gradient for h0)
        .Ret<ffi::Buffer<ffi::BF16>>()   // dw
        .Ret<ffi::Buffer<ffi::BF16>>()   // dq
        .Ret<ffi::Buffer<ffi::BF16>>()   // dk
        .Ret<ffi::Buffer<ffi::BF16>>()   // dv
        .Ret<ffi::Buffer<ffi::BF16>>()   // da
        .Ret<ffi::Buffer<ffi::BF16>>()   // db
, {ffi::Traits::kCmdBufferCompatible});